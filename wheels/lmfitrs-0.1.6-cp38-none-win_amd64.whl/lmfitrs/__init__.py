from .lmfitrs import *

__doc__ = lmfitrs.__doc__
if hasattr(lmfitrs, "__all__"):
    __all__ = lmfitrs.__all__